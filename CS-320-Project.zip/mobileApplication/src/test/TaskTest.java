package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import model.Task;

class TaskTest {
	
	@Test
	void testTaskConstructed() {
		Task myTask = new Task("id", "name", "description");  // used as error-free object creation for later tests
		// cover getters and setters
		assertTrue(myTask.getId().equals("id"));
		assertTrue(myTask.getName().equals("name"));
		assertTrue(myTask.getDescription().equals("description"));
		
		myTask.setName("good name");
		myTask.setDescription("good description");
	}
	
	// verify id too long
	@Test
	void testIdTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task myTask = new Task("12345678911", "name", "description");
		});
	}
	// verify id null
	@Test
	void testIdNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task myTask = new Task(null, "name", "description");
		});
	}
	// create task, set id, verify access exception
	// there is no setId method, and the id is private, so no update is possible as required.
	
	// verify name too long
	@Test
	void testNameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task myTask = new Task("id", "TwentyOneCharacterNam", "description");
		});
	}
	// verify name null
	@Test
	void testNameNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task myTask = new Task("id", null, "description");
		});
	}
	// create task successfully, set name too long, verify exception
	@Test
	void testNameTooLongUpdate() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task myTask = new Task("id", "name", "description");
			myTask.setName("TwentyOneCharacterNam");
		});
	}
	// create task successfully, set name null, verify exception
	@Test
	void testNameNullUpdate() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task myTask = new Task("id", "name", "description");
			myTask.setName(null);
		});
	}
	
	// verify description too long
	@Test
	void testDescriptionTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task myTask = new Task("id", "name", "This Description is way too long for the requiremen");
		});
	}
	// verify description null
	@Test
	void testDescriptionNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task myTask = new Task("id", "name", null);
		});
	}
	// create task successfully, set description too long, verify exception
	@Test
	void testDescriptionTooLongUpdate() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task myTask = new Task("id", "name", "description");
			myTask.setDescription("This Description is way too long for the requiremen");
		});
	}
	// create task successfully, set description null, verify exception
	@Test
	void testDescriptionNullUpdate() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task myTask = new Task("id", "name", "description");
			myTask.setDescription(null);
		});
	}

}
