package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import model.Appointment;
import services.AppointmentService;

class AppointmentServiceTest {

	// successful base case
	@Test
	void testAddAppointment() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(),
				date.getMinutes() + 1);
		Appointment appointment = new Appointment("goodId", futureDate, "Good Description");
		AppointmentService service = new AppointmentService();
		assertTrue(service.getList().size() == 0);
		service.addAppointment(appointment);
		assertTrue(service.getList().size() == 1);

	}

	// add two appointments with same id's, verify one length
	@Test
	void testAddSameAppointmentIds() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(),
				date.getMinutes() + 1);
		Appointment appointment1 = new Appointment("goodId", futureDate, "Good Description");
		Appointment appointment2 = new Appointment("goodId", futureDate, "Good Description");
		AppointmentService service = new AppointmentService();
		assertTrue(service.getList().size() == 0);
		service.addAppointment(appointment1);
		service.addAppointment(appointment2);
		assertTrue(service.getList().size() == 1);

	}

	// delete appointment when it exists in list
	@Test
	void testDeleteOneAppointment() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(),
				date.getMinutes() + 1);
		Appointment appointment1 = new Appointment("goodId", futureDate, "Good Description");
		Appointment appointment2 = new Appointment("goodIdTwo", futureDate, "Good Description");
		AppointmentService service = new AppointmentService();
		assertTrue(service.getList().size() == 0);
		service.addAppointment(appointment1);
		service.addAppointment(appointment2);
		assertTrue(service.getList().size() == 2);
		service.deleteAppointment("goodIdTwo");
		assertTrue(service.getList().size() == 1);
	}

	// try to delete appointment when id is not in list
	@Test
	void testDeleteAppointmentWhenNotInList() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(),
				date.getMinutes() + 1);
		Appointment appointment1 = new Appointment("goodId", futureDate, "Good Description");
		AppointmentService service = new AppointmentService();
		assertTrue(service.getList().size() == 0);
		service.addAppointment(appointment1);
		assertTrue(service.getList().size() == 1);
		service.deleteAppointment("NotInList");
		assertTrue(service.getList().size() == 1);
	}

}
