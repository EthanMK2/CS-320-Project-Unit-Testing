package services;

import java.util.ArrayList;

import model.Contact;

public class ContactService {

	// uses ArrayList for unspecified number of Contacts
	private ArrayList<Contact> contactList = new ArrayList<Contact>();

	public ContactService() {
	}

	// getter
	public ArrayList<Contact> getContactList() {
		return this.contactList;
	}

	// methods

	// return position of contact in list
	public int positionOfContact(String contactId) {
		for (int i = 0; i < this.contactList.size(); i++) {
			String currentContactId = this.contactList.get(i).getId();

			if (currentContactId == contactId) {
				return i;
			}
		}
		// not in list
		return -1;
	}

	public void addContact(Contact newContact) {

		if (this.positionOfContact(newContact.getId()) != -1) {
			System.out.println("Contact Already in List.");
			return;
		} else {
			// contact added
			this.contactList.add(newContact);
		}

	}

	public void deleteContact(String contactId) {
		int positionInList = this.positionOfContact(contactId);
		if (positionInList != -1) {
			this.contactList.remove(positionInList);
			System.out.println("Contact Deleted");
			return;
		} else {
			System.out.println("Not Deleted: Not Found in List.");
			return;
		}
	}

	public void updateFirstName(String contactId, String newFirstName) {
		int positionInList = this.positionOfContact(contactId);
		if (positionInList != -1) {
			this.contactList.get(positionInList).setFirstName(newFirstName);
			return;
		} else {
			System.out.println("First Name Not Updated: Not Found in List.");
			return;
		}
	}

	public void updateLastName(String contactId, String newLastName) {
		int positionInList = this.positionOfContact(contactId);
		if (positionInList != -1) {
			this.contactList.get(positionInList).setLastName(newLastName);
			return;
		} else {
			System.out.println("Last Name Not Updated: Not Found in List.");
			return;
		}
	}

	public void updatePhone(String contactId, String newPhone) {
		int positionInList = this.positionOfContact(contactId);
		if (positionInList != -1) {
			this.contactList.get(positionInList).setPhone(newPhone);
			return;
		} else {
			System.out.println("Phone Not Updated: Not Found in List.");
			return;
		}
	}

	public void updateAddress(String contactId, String newAddress) {
		int positionInList = this.positionOfContact(contactId);
		if (positionInList != -1) {
			this.contactList.get(positionInList).setAddress(newAddress);
			return;
		} else {
			System.out.println("Not Updated: Not Found in List.");
			return;
		}
	}

}