package services;

import java.util.ArrayList;

import model.Task;


public class TaskService {
	private ArrayList<Task> taskList = new ArrayList<Task>();

	public TaskService() {
	}
	
	public ArrayList<Task> getTaskList() {
		return this.taskList;
	}

	// return position of task in list
	public int positionOfTask(String taskId) {
		for (int i = 0; i < this.taskList.size(); i++) {
			String currentTaskId = this.taskList.get(i).getId();

			if (currentTaskId == taskId) {
				return i;
			}
		}
		// not in list
		return -1;
	}
	
	// add task with unique ID
	public void addTask(Task task) {
		if (task == null || positionOfTask(task.getId()) != -1) {  // in list
			System.out.println("Task already in list, duplicate Id, or null task.");
			return;
		} else {
			taskList.add(task);
		}
	}
	
	// delete task with ID
	public void deleteTask(String taskId) {
		if (positionOfTask(taskId) != -1) {  // in list
			taskList.remove(positionOfTask(taskId));
			return;
		} else {
			System.out.println("Task not in list: not deleted.");
		}
	}
	
	// update name with ID
	public void updateTaskName(String taskId, String newName) {
		if (positionOfTask(taskId) != -1) {
			taskList.get(positionOfTask(taskId)).setName(newName);  // set name
			return;
		} else {
			System.out.println("Task not in list. Name not updated.");
		}
	}
	
	// update description with ID
	public void updateTaskDescription(String taskId, String newDescription) {
		if (positionOfTask(taskId) != -1) {
			taskList.get(positionOfTask(taskId)).setDescription(newDescription);  // set description
			return;
		} else {
			System.out.println("Task not in list. Description not updated.");
		}
	}

}