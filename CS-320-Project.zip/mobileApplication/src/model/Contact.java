package model;

public class Contact {

	private String contactId;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;

	// constructor
	public Contact(String contactId, String firstName, String lastName, String phone, String address) throws Exception {
		if (contactId == null || contactId.length() > 10) { // only set once and throws exception if the ID is invalid
			throw new IllegalArgumentException("ID must exist and be less than or equal to 10 total characters.");
		}

		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException(
					"First Name must exist and be less than or equal to 10 total characters.");
		}

		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException(
					"Last Name must exist and be less than or equal to 10 total characters.");
		}

		if (phone == null || phone.length() != 10) {
			throw new IllegalArgumentException("Phone number must exist and be exactly 10 total characters.");
		}

		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Address must exist and be less than or equal to 30 total characters.");
		}

		setId(contactId);
		setFirstName(firstName);
		setLastName(lastName);
		setPhone(phone);
		setAddress(address);
	}

	// getters
	public String getId() {
		return this.contactId;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public String getPhone() {
		return this.phone;
	}

	public String getAddress() {
		return this.address;
	}

	// setters
	// contactId is only set once (private method): only in constructor
	private void setId(String Id) {
		this.contactId = Id;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}