package services;

import java.util.ArrayList;

import model.Appointment;

public class AppointmentService {
	private ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();
	
	public AppointmentService() {
		
	}
	
	public ArrayList<Appointment> getList() {
		return this.appointmentList;
	}
	
	// add appointments to list with unique id
	public void addAppointment(Appointment appointment) {
		for (int i = 0; i < this.appointmentList.size(); i++) {
			if (appointmentList.get(i).getId().equals(appointment.getId())) {
				System.out.println("Unique ID appointment already in list.");
				return;
			}
		}
		
		this.appointmentList.add(appointment);
	}
	
	// delete appointments from list by id
	public void deleteAppointment(String Id) {
		for (int i = 0; i < this.appointmentList.size(); i++) {
			if (appointmentList.get(i).getId().equals(Id)) {
				appointmentList.remove(i);
				System.out.println("Appointment Deleted");
				return;
			}
		}
		
		System.out.println("Appointment Not Found: Not Deleted.");
	}
	
}
