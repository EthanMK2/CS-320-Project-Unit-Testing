package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import model.Contact;

class ContactTest {
	
	@Test
	void testContactConstructed() {
		try {
			new Contact("ID", "first", "last", "1234567891", "address");
		} catch (Exception error) {
			fail("failed to create successful contact object");
		}
	}
	
	@Test
	void testIdTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678911", "first", "last", "1234567891", "address");
		});

	}
	
	@Test
	void testIdIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "first", "last", "1234567891", "address");
		});

	}
	
	@Test
	void testFirstNameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("ID", "12345678910", "last", "1234567891", "address");
		});

	}
	
	@Test
	void testFirstNameIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("ID", null, "last", "1234567891", "address");
		});

	}
	
	@Test
	void testLastNameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("ID", "first", "12345678910", "1234567891", "address");
		});

	}
	
	@Test
	void testLastNameIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("ID", "first", null, "1234567891", "address");
		});

	}
	
	@Test
	void testPhoneNotTenLower() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("ID", "first", "last", "", "address");
		});

	}
	
	@Test
	void testPhoneNotTenUpper() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("ID", "first", "last", "12345678910", "address");
		});

	}
	
	@Test
	void testPhoneIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("ID", "first", "last", null, "address");
		});

	}
	
	@Test
	void testAddressTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("ID", "first", "last", "1234567891", " Address Is Way Too Long For System ");
		});

	}
	
	@Test
	void testAddressIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("ID", "first", "last", "1234567891", null);
		});

	}

}