package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import model.Task;
import services.TaskService;

class TaskServiceTest {

	@Test
	void testTaskServiceCreated() {  // verify working task and list exists
		TaskService myTaskService = new TaskService();
		assertTrue(myTaskService.getTaskList().size() == 0);
		Task myTask = new Task("id", "name", "description");
		myTaskService.addTask(myTask);
		assertTrue(myTaskService.getTaskList().size() == 1);
	}
	
	// add three tasks with same ID, verify list length 1
	@Test
	void testUniqueIds() {
		TaskService taskService = new TaskService();
		Task task1 = new Task("id", "name1", "description");
		Task task2 = new Task("id", "name2", "description");
		Task task3 = new Task("id", "name3", "description");
		taskService.addTask(task1);
		taskService.addTask(task2);
		taskService.addTask(task3);
		assertTrue(taskService.getTaskList().size() == 1);
	}
	
	// add task, delete task, verify list length 0
	@Test
	void testDeleteTask() {
		TaskService taskService = new TaskService();
		Task task1 = new Task("id", "name1", "description");
		taskService.addTask(task1);
		assertTrue(taskService.getTaskList().size() == 1);
		taskService.deleteTask("id");
		assertTrue(taskService.getTaskList().size() == 0);
	}
	
	// add task, delete task with wrong ID, verify list length 1
	@Test
	void testDeleteFailed() {
		TaskService taskService = new TaskService();
		Task task1 = new Task("id", "name1", "description");
		taskService.addTask(task1);
		assertTrue(taskService.getTaskList().size() == 1);
		taskService.deleteTask("WrongID");
		assertTrue(taskService.getTaskList().size() == 1);
	}
	
	// add null task, verify list length 0
	@Test
	void testAddNullTask() {
		TaskService taskService = new TaskService();
		taskService.addTask(null);
		assertTrue(taskService.getTaskList().size() == 0);
	}
	
	// add task, update name, verify name
	@Test
	void testUpdateName() {
		TaskService taskService = new TaskService();
		Task task1 = new Task("id", "name1", "description");
		taskService.addTask(task1);
		assertTrue(taskService.getTaskList().size() == 1);
		taskService.updateTaskName("id", "newName");
		String taskName = taskService.getTaskList().get(taskService.positionOfTask("id")).getName();
		assertTrue(taskName == "newName");
	}
	
	// add task, update name with wrong taskID, verify original name
	@Test
	void testUpdateNameFailed() {
		TaskService taskService = new TaskService();
		Task task1 = new Task("id", "name1", "description");
		taskService.addTask(task1);
		assertTrue(taskService.getTaskList().size() == 1);
		assertTrue(taskService.getTaskList().get(0).getId().equals("id"));  // proves task is there
		taskService.updateTaskName("WRONGID", "newName");
		String taskName = taskService.getTaskList().get(taskService.positionOfTask("id")).getName();
		assertTrue(taskName == "name1");
	}
	
	// add task, update description, verify description
	@Test
	void testUpdateDescription() {
		TaskService taskService = new TaskService();
		Task task1 = new Task("id", "name1", "description");
		taskService.addTask(task1);
		assertTrue(taskService.getTaskList().size() == 1);
		taskService.updateTaskDescription("id", "New Description");
		String taskDescription = taskService.getTaskList().get(taskService.positionOfTask("id")).getDescription();
		assertTrue(taskDescription == "New Description");
	}
	
	// add task, update description with wrong taskID, verify original name
	@Test
	void testUpdateDescriptionFailed() {
		TaskService taskService = new TaskService();
		Task task1 = new Task("id", "name1", "description");
		taskService.addTask(task1);
		assertTrue(taskService.getTaskList().size() == 1);
		taskService.updateTaskDescription("WRONGID", "New Description");
		String taskDescription = taskService.getTaskList().get(taskService.positionOfTask("id")).getDescription();
		assertTrue(taskDescription == "description");
	}

}