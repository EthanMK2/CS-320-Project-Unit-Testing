package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import services.ContactService;
import model.Contact;

class ContactServiceTest {

	// add three contacts, verify length 3
	@Test
	void testContactListLength() {
		ContactService service = new ContactService();
		try {
			Contact contact1 = new Contact("testID1", "testFirst", "testLast", "1234567891", "testAddress");
			Contact contact2 = new Contact("testID2", "testFirst", "testLast", "1234567891", "testAddress");
			Contact contact3 = new Contact("testID3", "testFirst", "testLast", "1234567891", "testAddress");
			assertTrue(service.getContactList().size() == 0);
			service.addContact(contact1);
			service.addContact(contact2);
			service.addContact(contact3);
			assertTrue(service.getContactList().size() == 3);
		} catch (Exception error) {
			fail("Contact Creation Failed");
		}

	}

	// add three contacts with same ids, verify length 1
	@Test
	void testContactUniqueIds() {
		ContactService service = new ContactService();
		try {
			Contact contact1 = new Contact("SAMEID", "testFirst", "testLast", "1234567891", "testAddress");
			Contact contact2 = new Contact("SAMEID", "testFirst", "testLast", "1234567891", "testAddress");
			Contact contact3 = new Contact("SAMEID", "testFirst", "testLast", "1234567891", "testAddress");
			service.addContact(contact1);
			service.addContact(contact2);
			service.addContact(contact3);
			assertTrue(service.getContactList().size() == 1);
		} catch (Exception error) {
			fail("Contact Creation Failed");
		}

	}

	// add three contacts with different ids, delete one, verify length 2
	@Test
	void testContactDeletion() {
		ContactService service = new ContactService();
		try {
			Contact contact1 = new Contact("testID1", "testFirst", "testLast", "1234567891", "testAddress");
			Contact contact2 = new Contact("testID2", "testFirst", "testLast", "1234567891", "testAddress");
			Contact contact3 = new Contact("testID3", "testFirst", "testLast", "1234567891", "testAddress");
			service.addContact(contact1);
			service.addContact(contact2);
			service.addContact(contact3);
			assertTrue(service.getContactList().size() == 3);
			service.deleteContact(contact1.getId());
			assertTrue(service.getContactList().size() == 2);
		} catch (Exception error) {
			fail("Contact Creation Failed");
		}

	}

	// add contact, update contactId, verify IllegalAccessException exception thrown
	// COMMENTED OUT BECAUSE setID() METHOD IS NOT VISIBLE, SO THE IMMUTABILITY OF
	// THE CONTACT ID IS SECURE (throws error, untestable in junit)
	// @Test
	// void testContactIdImmutable() {
	// ContactService service = new ContactService();
	// try {
	// Contact contact1 = new Contact("testID", "testFirst", "testLast",
	// "1234567891", "testAddress");
	// service.addContact(contact1);
	// assertThrows(IllegalAccessException.class, () -> {
	// service.getContactList().get(0).setId("InvalidAccess");
	// });
	// } catch (Exception error) {
	// fail("Contact Creation Failed");
	// }
	//
	// }

	// add contact, update with new first name, verify new first name
	@Test
	void testUpdateFirstName() {
		ContactService service = new ContactService();
		try {
			Contact contact1 = new Contact("SAMEID", "unchanged", "testLast", "1234567891", "testAddress");
			service.addContact(contact1);
			assertTrue(service.getContactList().get(0).getFirstName().equals("unchanged"));
			service.updateFirstName(contact1.getId(), "changed");
			assertTrue(service.getContactList().get(0).getFirstName().equals("changed"));
		} catch (Exception error) {
			fail("Contact Creation Failed");
		}

	}

	// add contact, update with new last name, verify new last name
	@Test
	void testUpdateLastName() {
		ContactService service = new ContactService();
		try {
			Contact contact1 = new Contact("SAMEID", "testFirst", "unchanged", "1234567891", "testAddress");
			service.addContact(contact1);
			assertTrue(service.getContactList().get(0).getLastName().equals("unchanged"));
			service.updateLastName(contact1.getId(), "changed");
			assertTrue(service.getContactList().get(0).getLastName().equals("changed"));
		} catch (Exception error) {
			fail("Contact Creation Failed");
		}

	}

	// add contact, update with new phone, verify new phone number
	@Test
	void testUpdatePhone() {
		ContactService service = new ContactService();
		try {
			Contact contact1 = new Contact("SAMEID", "testFirst", "testLast", "1234567891", "testAddress");
			service.addContact(contact1);
			assertTrue(service.getContactList().get(0).getPhone().equals("1234567891"));
			service.updatePhone(contact1.getId(), "1111111111");
			assertTrue(service.getContactList().get(0).getPhone().equals("1111111111"));
		} catch (Exception error) {
			fail("Contact Creation Failed");
		}

	}

	// add contact, update with new address, verify new address
	@Test
	void testUpdateAddress() {
		ContactService service = new ContactService();
		try {
			Contact contact1 = new Contact("SAMEID", "testFirst", "testLast", "1234567891", "unchanged");
			service.addContact(contact1);
			assertTrue(service.getContactList().get(0).getAddress().equals("unchanged"));
			service.updateAddress(contact1.getId(), "changed");
			assertTrue(service.getContactList().get(0).getAddress().equals("changed"));
		} catch (Exception error) {
			fail("Contact Creation Failed");
		}

	}
}
