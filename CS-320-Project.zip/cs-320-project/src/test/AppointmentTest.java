package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import model.Appointment;

class AppointmentTest {

	// base case where these values work. each value will be changed for each focused test
	@Test
	void testAppointmentCreationSuccessful() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + 1);
		Appointment appointment = new Appointment("goodId", futureDate, "Good Description");
		assertTrue(appointment.getId().equals("goodId"));
	}
	
	// id is too long (> 10 characters)
	@Test
	void testIdTooLong() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + 1);
		assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("ElevenChars", futureDate, "Good Description");
		});
	
	}
	// id is null
	@Test
	void testIdIsNull() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + 1);
		assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment(null, futureDate, "Good Description");
		});
	
	}
	
	// id cannot be updated because the attribute is private and there is no setter for the Id
	
	// date is in the past
	@Test
	void testAppointmentOutOfDate() {
		Date date = new Date();
		Date pastDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() - 1);
		assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("goodId", pastDate, "Good Description");
		});
	
	}
	
	// date is null
	@Test
	void testDateIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("goodId", null, "Good Description");
		});
	
	}
	
	// use successful update method: date is in the future
	@Test
	void testUpdateDateSuccess() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + 1);
		Date anotherFutureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + 2);
		Appointment appointment = new Appointment("goodId", futureDate, "Good Description");
		appointment.setDate(anotherFutureDate);
		assertFalse(futureDate.equals(anotherFutureDate));
		assertTrue(appointment.getDate().equals(anotherFutureDate));
	
	}
	
	// use update method: date is in the past
	@Test
	void testUpdateDateInPast() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + 1);
		Date pastDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() - 1);
		Appointment appointment = new Appointment("goodId", futureDate, "Good Description");
		assertThrows(IllegalArgumentException.class, () -> {
			appointment.setDate(pastDate);
		});
	
	}
	
	// use update method: date is null
	@Test
	void testUpdateDateIsNull() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + 1);
		Appointment appointment = new Appointment("goodId", futureDate, "Good Description");
		assertThrows(IllegalArgumentException.class, () -> {
			appointment.setDate(null);
		});
	
	}
	
	// description is too long (> 50 characters)
	@Test
	void testDescriptionTooLong() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + 1);
		assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("goodId", futureDate, "Description is too long for the system to handle 51");
		});
	
	}
	
	// description is null
	@Test
	void testDescriptionIsNull() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + 1);
		assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("goodId", futureDate, null);
		});
	
	}
	
	// use successful update method: description is good
	@Test
	void testUpdateDescriptionSuccess() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + 1);
		String goodNewDescription = "Another Good Description";
		Appointment appointment = new Appointment("goodId", futureDate, "Good Description");
		appointment.setDescription(goodNewDescription);
		assertTrue(appointment.getDescription().equals("Another Good Description"));
	
	}
	
	// use update method: description is too long (> 50 characters)
	@Test
	void testUpdateDescriptionTooLong() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + 1);
		Appointment appointment = new Appointment("goodId", futureDate, "Good Description");
		assertThrows(IllegalArgumentException.class, () -> {
			appointment.setDescription("Description is too long for the system to handle 51");
		});
	
	}
	
	// use update method: description is null
	@Test
	void testUpdateDescriptionIsNull() {
		Date date = new Date();
		Date futureDate = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + 1);
		Appointment appointment = new Appointment("goodId", futureDate, "Good Description");
		assertThrows(IllegalArgumentException.class, () -> {
			appointment.setDescription(null);
		});
	
	}

}
