package model;

import java.util.Date;

public class Appointment {
	private String appointmentId;
	private Date appointmentDate;
	private String appointmentDescription;
	
	// Id must be 10 characters or less and not null
	// date must be in the past
	// description must be 50 characters or less and not null
	public Appointment(String Id, Date date, String description) {
		if (Id == null || Id.length() > 10) {
			throw new IllegalArgumentException();
		}
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException();
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException();
		}
		
		this.appointmentId = Id;
		this.appointmentDate = date;
		this.appointmentDescription = description;
	}
	
	public String getId() {
		return this.appointmentId;
	}
	
	public Date getDate() {
		return this.appointmentDate;
	}
	
	public String getDescription() {
		return this.appointmentDescription;
	}
	
	// date must be in past and not null
	public void setDate(Date date) {
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException();
		}
		
		this.appointmentDate = date;
	}
	
	// description must be 50 characters or less and not null
	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException();
		}
		
		this.appointmentDescription = description;
	}
	
}